const prankmenu = (prefix) => {
	return `
Grupos Oficiais 
Grupo 1: https://chat.whatsapp.com/Faya6RMm7tS2nMfhtWsEDR
Grupo 2: https://chat.whatsapp.com/Eoa9BcYIoKN9d483ZpOVZn
`
}

exports.prankmenu = prankmenu

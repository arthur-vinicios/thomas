const perfil =(nameuser,usernum, usertime, userdesc, usertype, prefix, sender,getLevelingLevel,usergroup, groupName, user, apoia1, blocked, date, time,getLevelingXp,idadeuser) => {
	let sen =  usernum
	

	return `
╔════✪〘 Perfil Do Usúario 〙✪════╗
║                                  
╠➫ *Nome:* ${nameuser}                                        
║  
╠➫ *Idade:* ${idadeuser}
║                                               
╠➫ *Level:* ${getLevelingLevel}
║                               
╠➫ *Xp:* ${getLevelingXp  }               
║                              
╠➫ *Numero:* wa.me/${sen}               
║                              
╠➫ *ADM?:* pau                
║                                       
╠➫  *DESCRIÇÃO:* ${userdesc}         
║                              
╠➫ *levelcom:* ${usertype}           
║                           
╠➫ *DATA DE REGISTRO:*  ${usertime.split(' ')[0]}                            
║
╠➫ *HORA DO REGISTRO:* ${usertime.split(' ')[1]} 
║
╠➫ *GRUPO DE REGISTRO:* *${usergroup}* 
║ 
╠➫ *É DE TOTAL RESPONSABILIDADE DOS USUARIOS A MANEIRA COM QUE USA A SUA INFORMAÇÃO, PARA SUA SEGURANÇA USAMOS _LGPD_*
║
╚════✪〘  Perfil Do Usúario 〙✪════╝
`
}

exports.perfil = perfil

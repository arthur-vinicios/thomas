const regras_bonde = (prefix, namebot) => {
	return `

 REGRAS PARA ADICIONAR O ${namebot} EM SEU BONDE OU PROJETO

 O BONDE OU PROJETO QUE SOLICITAR A PRESENÇA DO BOT ${namebot}, DEVERA SEGUIR DE ACORDO COM SUAS DIRETRIZES, DO  CONTRÁRIO O BOT NÃO FICARÁ

 SENDO DIRETRIZES DO BOT

 ◆➤ ⚠️ 1 CRIAR INTERAÇÃO ENTRE OS USUÁRIOS ATRAVÉS DO LEVEL E SEUS JOGOS

 ◆➤ ⚠️ 2 SEM FLOOD OU E BAN

 ◆➤ ⚠️ 3 TER RESPEITO E SER RESPEITADO
 
 Requisitos para manter  bot no seu BONDE OU PROJETO
 
 ◆➤ ⚠️ 1 Acesse *_https://sites.google.com/view/albion-desenvolvedor/registra-grupo_*
 
 *Registre o BONDE OU PROJETO!* ou baixe nosso app [ ~ANDROID~ ] em: _*https://sites.google.com/view/albion-desenvolvedor/download/app*_
 
 
 ◆➤ ⚠️ 2  *SER MAIOR QUE NÍVEL 3 [ Não é nescesario se você registrar o BONDE OU PROJETO ou acessa e registrar pelo app ]*
  
 ◆➤ ⚠️ 3 *DEVERÁ ESTÁ É PERMANECE NO GRUPO DE CONTROLE (Digite ${prefix}gpof )*
 

 
`
}

exports.regras_bonde = regras_bonde

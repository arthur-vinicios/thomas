const moment = require('moment-timezone')
const {
default:
makeWASocket,
DisconnectReason,
useSingleFileAuthState,
makeInMemoryStore,
MessageType, 
MessageOptions, 
Mimetype,
downloadMediaMessage
} = require("@adiwajshing/baileys")
const fs = require("fs")
const P = require("pino")
const { exec } = require('child_process')
const { color } = require("./lib/color")
const { perfil } = require('./Menu/perfil')
const { menuadmin } = require('./Menu/menuadmin')
const { perfilmenu } = require('./Menu/perfilmenu')
const { regras_add } = require('./Menu/regras_add')
const { levelcom } = require('./Menu/levelcom')
const { menujogos } = require('./Menu/menujogos')
const { regras_bonde } = require('./Menu/regras_bonde')
const { gpof } = require('./Menu/gpof')
const { negara } = require('./Menu/kodenegara')
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close, version } = require('./lib/functions')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const { help } = require('./Menu/help')
try{

global.store = makeInMemoryStore({ })
store.readFromFile("./.dados.json")
setInterval(() => {
store.writeToFile("./.dados.json") }, 10_000) } catch(e){
if (String(e).includes(".json") ){
nome = `${String(e).split("'")[1].split("/")[3]}`
if( String(e).includes("ENOENT:")){console.log(`Erro: #X002\n\no json ${nome}\n não foi encontrado\n`)}else{
console.log(`error detectado ${nome}`)
console.log("Erro #X000")}
}} try{
global.youprofile = JSON.parse(fs.readFileSync("./database/json/YouProfile.json"))
global.prefix = youprofile.Prefix
global.userban = JSON.parse(fs.readFileSync('./database/json/userban.json'))
global.welkom = JSON.parse(fs.readFileSync('./database/json/welkom.json'))
global.nsfw = JSON.parse(fs.readFileSync('./database/json/nsfw.json'))
global.samih = JSON.parse(fs.readFileSync('./database/json/simi.json'))
global._leveling = JSON.parse(fs.readFileSync('./database/json/leveling.json'))
global.bdn = JSON.parse(fs.readFileSync('./database/json/bdn.json'))
global.daftor = JSON.parse(fs.readFileSync('./database/json/daftar.json'))
global.usnio = JSON.parse(fs.readFileSync('./database/json/usnio.json'))
global.at = JSON.parse(fs.readFileSync('./database/json/at.json'))
global.users = JSON.parse(fs.readFileSync('./database/json/users.json'))
global.user = JSON.parse(fs.readFileSync('./database/json/user.json'))
global._level = JSON.parse(fs.readFileSync('./database/json/level.json'))
global.x = JSON.parse(fs.readFileSync('./database/json/x9.json'))
}catch (e){
if (String(e).includes(".json") || String(e).includes("ENOENT:")){
nome = `${String(e).split("'")[1].split("/")[3]}`
console.log(`error detectado ${nome} #x002`)
if (nome === 'YouProfile.json' ){
exec(`cd database/json/ ; echo {'"Botname"':'"Albion"','"Prefix"':'"!"','"AlbionID"':'"0000AAAA"','"Owner"':'"5516999469735@s.whatsapp.net"','"face"':'"ok"','"insta"':'"lsksks"'}>>${nome}`)
process.exit(0)
} else{
exec(`cd database/json/ ; echo []>>${nome}`)
process.exit(0)
}

}else {
console.log(e)
process.exit(0)
}}

const getLevelingXp = (userId) => { //prgar a quantidade de xp do usuario
            let position = false
            Object.keys(_level).forEach((i) => {
if (_level[i].jid === userId) {
    position = i
}
            })
            if (position !== false) {
return _level[position].xp
            }
        }

        const getLevelingLevel = (userId) => { // pegar o level do usuario
            let position = false
            Object.keys(_level).forEach((i) => {
if (_level[i].jid === userId) {
    position = i
}
            })
            if (position !== false) {
return _level[position].level
            }
        }

        const getLevelingId = (userId) => { //pegar o nyumero do usuario
            let position = false
            Object.keys(_level).forEach((i) => {
if (_level[i].jid === userId) {
    position = i
}
            })
            if (position !== false) {
return _level[position].jid
            }
        }

        const addLevelingXp = (userId, amount) => { //adciona xp
            let position = false
            Object.keys(_level).forEach((i) => {
if (_level[i].jid === userId) {
    position = i
}
            })
            if (position !== false) {
_level[position].xp += amount
fs.writeFileSync('./database/json/level.json', JSON.stringify(_level))
            }
        }
 const removexp = (userId, amount) => { //remove xp
            let position = false
            Object.keys(_level).forEach((i) => {
if (_level[i].jid === userId) {
    position = i
}
            })
            if (position !== false) {
_level[position].xp -= amount
fs.writeFileSync('./database/json/level.json', JSON.stringify(_level))
            }
        }
        const addLevelingLevel = (userId, amount) => { // adciona lvel
            let position = false
            Object.keys(_level).forEach((i) => {
if (_level[i].jid === userId) {
    position = i
}
            })
            if (position !== false) {
_level[position].level += amount
fs.writeFileSync('./database/json/level.json', JSON.stringify(_level))
            }
        }

        const addLevelingId = (userId) => { //faz cadastro
let ups = {jid: userId, xp: 0, level: 1}
_level.push(ups)
fs.writeFileSync('./database/json/level.json', JSON.stringify(_level))    
}
async function Albion () {
console.log(banner.string)
const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n' 
            + 'FN:Albion Desenvolvedor\n' // full name
            + 'ORG:Albion Desenvolvedor;\n' // the organization of the contact
            + 'TEL;type=CELL;type=VOICE;waid=5516999469735 +55 9 9946-9735\n' // WhatsApp ID + phone number
            + 'END:VCARD'
const { state, saveState } = await useSingleFileAuthState("./.Albion_Desenvolvedor")
const conn = makeWASocket({
logger: P({ level: "silent" }),
printQRInTerminal: true,
auth: state
})

conn.ev.on ("creds.update", saveState)


conn.ev.on("connection.update", (update) => {

const { connection, lastDisconnect } = update
if(connection === "close") {
const shouldReconnect = (lastDisconnect.error).output.statusCode !== DisconnectReason.loggedOut
console.log("Conexão fechada devido a", lastDisconnect.error, "Tentando reconectar...", shouldReconnect)
if (lastDisconnect.error.output.payload.error == "Unauthorized"){
  exec(`rm -rf .dados.json `)
  exec(`rm -rf .Albion_Desenvolvedor `)
  console.log("ptoblema corrigido")
  process.exit(0)
  }
if(shouldReconnect) {
Albion()
}

} else if(connection === "open") {
console.log("\n\nConexão aberta\n\n")
}

})
try {
conn.ev.on("messages.upsert",  async m =>{
global.apoia1 = 'https://albion-desenvolvedor.herokuapp.com'
global.blocked = await conn.fetchBlocklist().then( json =>{
return json}).catch(json =>{console.log(json)})
global.namebot = youprofile.Botname
const mek = m.messages[0]
const from = mek.key.remoteJid
console.log(from)
const isGroup = mek.key.remoteJid.endsWith("@g.us")
const isWelkom = isGroup ? welkom.includes(from) : false
const x9 = isGroup ? x.includes(from) : false
if(m.type === 'append' ) {
const base = await JSON.parse(JSON.stringify(m.messages[0]))

const reply = (teks) => {
conn.sendMessage(from,{ text: String(teks)}, {quoted:mek})}
	
t = base.messageStubType
qf = base.key.participant
const datagroup = isGroup ? await conn.groupMetadata(from) : "0"
console.log(datagroup)
//console.log(mek)
console.log(from)
console.log(isGroup ? groupMetadata.subject : "87")
if (!x9){		
if (t === 'GROUP_PARTICIPANT_PROMOTE'){ 
reply("Menbro Promovido.")
}
else if (t === 'GROUP_PARTICIPANT_DEMOTE'){ 
reply("menbro rebaixado")
}
else if (t === 'GROUP_PARTICIPANT_REMOVE'){
reply("menbro banido")
}
else if (t === 'GROUP_PARTICIPANT_ADD'){
reply("Bem vindo")
}
else if (t === 'GROUP_PARTICIPANT_LEAVE'){
reply("Ele saiu")
}
}if(isWelkom){
if (t === 'GROUP_PARTICIPANT_REMOVE'){
reply("menbro banido")

 
}
else if (t === 'GROUP_PARTICIPANT_ADD'){
reply("Bem vindo")

}
else if (t === 'GROUP_PARTICIPANT_LEAVE'){
reply("Ele saiu")

}
}}
const time = moment.tz('Etc/GMT+3').format('DD/MM HH:mm:ss')
const content = JSON.stringify(mek.message)
const date = time.split(" ")[0]
await conn.sendReadReceipt(mek.key.remoteJid, mek.key.participant, [mek.key.id])
if (!mek.key.participant) mek.key.participant = mek.key.remoteJid
mek.key.participant = mek.key.participant.replace(/:[0-9]+/gi, "")
if (!mek.message) return

const type = Object.keys(mek.message).find((key) => !['senderKeyDistributionMessage', 'messageContextInfo'].includes(key))
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close, version } = require('./lib/functions')

const body = (type === 'conversation' &&
mek.message.conversation.startsWith(prefix)) ?
mek.message.conversation: (type == 'imageMessage') &&
mek.message[type].caption.startsWith(prefix) ?
mek.message[type].caption: (type == 'videoMessage') &&
mek.message[type].caption.startsWith(prefix) ?
mek.message[type].caption: (type == 'extendedTextMessage') &&
mek.message[type].text.startsWith(prefix) ?
mek.message[type].text: (type == 'listResponseMessage') &&
mek.message[type].singleSelectReply.selectedRowId ?
mek.message.listResponseMessage.singleSelectReply.selectedRowId: (type == 'templateButtonReplyMessage') ?
mek.message.templateButtonReplyMessage.selectedId: (type === 'messageContextInfo') ?
mek.message[type].singleSelectReply.selectedRowId: (type == 'conn.sendMessageButtonMessage') &&
mek.message[type].selectedButtonId ?
mek.message[type].selectedButtonId: (type == 'stickerMessage') && ((mek.message[type].fileSha256.toString('base64')) !== null && (mek.message[type].fileSha256.toString('base64')) !== undefined) ? (mek.message[type].fileSha256.toString('base64')): ""
const botNumber = conn
const sender = isGroup ? mek.key.participant : mek.key.remoteJid
const groupMetadata = isGroup ? await conn.groupMetadata(from) : ""
const groupName = isGroup ? groupMetadata.subject : ""
const ownerNumber = youprofile.Owner// replace this with your number
const nomorOwner = [ownerNumber]
const isOwner = ownerNumber.includes(sender)
//const totalchat = await Albion.chats.all()
//const groupId = isGroup ? groupMetadata.jid : ''
const groupMembers = isGroup ? groupMetadata.participants : ''
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
const isGroupAdmins = groupAdmins.includes(sender) || isOwner || false
//const isWelkom = isGroup ? welkom.includes(from) : false
//const isNsfw = isGroup ? nsfw.includes(from) : false
//const isSimi = isGroup ? samih.includes(from) : false
 

at = 0
setTimeout(() => {
  console.log();
}, 4000)
var n = new Date();
atual_dia = String(n).split(' ')[2]
atual_hora = String(n).split(' ')[4].split(':')[0]
atual_minuto  = String(n).split(' ')[4].split(':')[1]
atual_segundo = String(n).split(' ')[4].split(':')[2]
data = time.split('/')[0] 
hora = time.split(':')[0].split(' ')[1]
minuto = time.split(':')[1]
segundos= time.split(':')[2]




const isUser = user.includes(sender)
const isLevelingOn = isGroup ? _leveling.includes(from) : true
const NomerOwner = youprofile.Owner
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
const isCmd = body.startsWith(prefix)
const pushname = mek.pushName ? mek.pushName : ""
const args = body.trim().split(/ +/).slice(1)
 const oros = body.slice(0).split('@').shift()

 const reply = (teks) => {
conn.sendMessage(from,{ text: String(teks)}, {quoted:mek})}
	
const sendMess = (hehe, teks) => {
conn.sendMessage(hehe, { text: String(teks)})
			}
			
			const sendcontact = (hehe) =>{ conn.sendMessage(
    from,
    { 
        contacts: { 
            displayName: 'Albion desenvolvedor', 
            contacts: [{ vcard }] 
        }
    }
)}
const men = (id, text,kj) => {
    conn.sendMessage(id, { text: text , mentions: kj},  {quoted:mek})
  }    
		
if(atual_dia === data){ 
if (atual_minuto === minuto){ 
if ( atual_hora === hora  ){
colors = ['red','white','black','blue','yellow','green']

// organizar os dados dos usuarios
if (userban.includes(sender)){
 console.log(userban)
 if (oros.includes(prefix)){
 
 return reply("Usuario bloqueado (A)")
}
 }
 
 if (daftor.includes(from)) {if (oros.includes(`rgt 0`)){
 if (!isGroup) return reply("triste")
 if (!isGroupAdmins) return reply("Sem Autorização")
 
		daftor.splice(from, 1)
		fs.writeFileSync('./database/json/daftar.json', JSON.stringify(daftor))
		reply('❬ SUCESSO ❭')}
 else{
 console.log("\n============================================================")
 console.log(`\n\n[❗]  Grupo ${groupName} está usando RGT \n\n`)
 console.log(`Grupo: ${groupName}\nUltima mensagem: ${oros}`)
 console.log(`\n\n[❗]  Grupo ${groupName} está usando RGT \n\n`) 
 console.log("============================================================\n")
 return 
 
 
}
 }
 
duf = 'n'
let position = false
Object.keys(users).forEach((i) => {
if (users[i].numero === sender.split('@')[0]) {
    position = i
} 
if (position !== false) {
 duf = 'sim'
 if (users[position].contype === "0" ){
nameuser = users[position].name
idadeuser = users[position].idade
usernum = users[position].numero
usertime = users[position].time1
userdate = date
userdesc = users[position].desc
usertype = users[position].contype
usergroup= users[position].Nome_do_grupo
id_base = users[position].id
levelcomm = users[position].levelcom

     }
  else if (users[position].contype === "1"){
  //È
  }
  else if (users[position].contype === "2") {
  //È
  } 
}

else{

           nameuser = "Desconhecido"
   
            
            }

        
})   


global.blocked = await conn.fetchBlocklist().then( json =>{
return json}).catch(json =>{console.log(json)})
// fim
if (isGroup && isLevelingOn && isUser) {
            const currentLevel = getLevelingLevel(sender)
            const checkId = getLevelingId(sender)
          
            try {
if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
const amountXp = 500
const requiredXp = 5000 * (Math.pow(2, currentLevel))
               
const getLevel = getLevelingLevel(sender)
global.getLevel
addLevelingXp(sender, amountXp)

if (requiredXp <= getLevelingXp(sender)) {
    addLevelingLevel(sender, 1)
    await reply(`*「 LEVEL UP 」*\n\n➸ *Nome*: ${nameuser}\n➸ *XP*: ${getLevelingXp(sender)}\n➸ *Level*: ${getLevel} -> ${getLevelingLevel(sender)}\n\nParabéns!! 🎉🎉`)
}
            } catch (err) {
console.error(err)
            }
        } 
mess = {
wait: '⌛ carregando... se eu não enviar tente novamente em 10s⌛',
success: '✔️ Successor ✔️',
           levelon: '❬ ✔ ❭ *habilitar Level*',
leveloff: ' ❬ X ❭  *desabilitar Level*',
levelnoton: '❬ X ❭ *level não ativo*',
levelnol: '*Pqp ksks level* 0 ',
error: {
stick: '[❗] Falha, ocorreu um erro ao converter a imagem em um adesivo ❌',
Iv: '❌ Link inválido ❌',
NotXp: `❌ Voçê não possui xp sufciente para isso! ❌`,
},
only: {
group: '[❗] Este comando só pode ser usado em grupos! ❌',
groupn: '[❗] Este comando só pode ser usado no pv! ❌',
ownerG: '[❗] Voçê não tem acesso a esse comando  ❌',
ownerB: '[❗] Acesso negado ❌',
admin: '[❗] Este comando só pode ser usado por administradores de grupo! ❌',
Badmin: '[❗] Este comando só pode ser usado quando o bot se torna administrador! ❌',
daftarB:`── 「REGISTRE-SE」 ──\n\nVOCÊ NÃO ESTÁ EM NOSSO BANCO DE DADOS DIGITE\n\n ${prefix}daftar Nome|Idade\n\n Segue o exemplo ${prefix}daftar ${namebot}|${time.split("/")[0]} `,
}
}
			
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
console.log(`\n\n`) }}}
			
	try{	
 global.templateButtons = [
    {index: 1, urlButton: {displayText: 'Acesse nosso grupo oficial!', url: 'https://chat.whatsapp.com/Ee1CGZJJmyl466XLt3tFTb'}},
    {index: 2, callButton: {displayText: 'Call me!', phoneNumber: '+55 (16) 996368121'}},
    {index: 3, quickReplyButton: {displayText: 'Menu Jogos!', id: `${prefix}menujogos`}},
]

 global.templateMessage = {
    text: help(prefix, sender,getLevelingLevel(sender),namebot, user, apoia1, blocked, date, time,nameuser,NomerOwner,youprofile.AlbionID,youprofile.face,youprofile.insta ),
    footer: 'Hello World',
    templateButtons: templateButtons
}
global.isMedia = (type === 'imageMessage' || type === 'videoMessage')
			global.isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			global.isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			global.isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			

}catch(e){console.log(e)}

switch (command) {
case "ownermenu":
	if(!isOwner) return reply() 
	reply(ownermenu(prefix))
	break
        
 case 'perfilmenu':
reply(perfilmenu(prefix, sender))
break
case 'menuadmin':
 if (!isGroupAdmins) return reply("Apenas pra adm.")
reply(menuadmin(prefix, sender))
break     	

case "menu":
console.log(user)
console.log()
const sendMsg = await conn.sendMessage(from, templateMessage)
reply(`Olá ${nameuser}, caso tenha problema use ${prefix}help`)
break
case 'help':
case 'pika':
reply(help(prefix, sender,getLevelingLevel(sender),namebot, user, apoia1, blocked, date, time,nameuser,NomerOwner,youprofile.AlbionID,youprofile.face,youprofile.insta ))
break
case 'gay':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE GAY*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break
		   
case 'bi':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE Bi*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break
		   case "hidetag":
		   		        if (!isGroupAdmins) return reply ('*ACESSO NEGADO*')

if (!isUser) return reply(mess.only.daftarB)
if (!isGroup) return reply(mess.only.group)
teks = body.slice(9)
group = await conn.groupMetadata(from);
member = group['participants']
jids = [];
member.map( async adm => {
jids.push(adm.id.replace('c.us', 's.whatsapp.net'));
 })

              await conn.sendMessage(from,{text: teks, mentions: jids}, {quoted:mek})
               break
		   
		   
case 'trans':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE Trans*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break
case 'lesbica':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE lesbica*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break		   
case 'Hetero':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE Hetero*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break		   
case 'tmpau':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o pau do (a) @${rate.split("@")[0]} TEMOS  seu tamanho:* ${anu}cm `
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break		   
case 'pan':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE Pan*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break
case 'burro':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE Burro`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
		   break
case 'Gado':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE gado*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
break
case 'Travequin':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE travequin*`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
break
case 'inteli':
case 'inteligencia':
case 'inteligência':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% *DE inteligente`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
break
case 'nivelloli':
case 'niveloli':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Entre todos o   @${rate.split("@")[0]} TEM A PORCENTAGEM:* ${anu}% no grupo`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
break
case 'nivelgay':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Entre todos o   @${rate.split("@")[0]} TEM A PORCENTAGEM:* ${anu}% no grupo`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
break
case 'sexy':
        if (!isUser) return reply("digite daftar nome|idade")	
	            	if (args.length < 1) return reply('marque seus amigos!')
rate = body.slice(4).split("@")[1]+'@s.whatsapp.net'

           
		   anu = `${Math.floor(Math.random() * 100)}`
		   
		   hasil = `*Após medir o  @${rate.split("@")[0]} TEMOS SUA PORCENTAGEM:* ${anu}% sexy`
		conn.sendMessage(from, { text: String(hasil), mentions: [rate]},  {quoted:mek})   
break
case "wa.me":
if (!isUser) return reply("digite daftar nome|idade")	
if (args.length < 1) {
reply(`wa.me/${sender.split("@")[0]}`)
}else{
reply(`https://api.whatsapp.com/send?phone=${sender.split("@")[0]}&text=`+encodeURI(body.slice(7)))
}
break
case "ownergroup":
Object.keys(groupMembers).forEach((i) => {
if (groupMembers[i].admin === 'superadmin') {
  return  p = i
}
            })
await conn.sendMessage(from,{text:`Este è o dono do grupo @${groupMembers[p].id.split("@")[0]}`, mentions: [groupMembers[p].id]},  {quoted:mek})
break	
case "blocklist":
msg =`  Total : ${blocked.length}\n`
for (let mem of blocked) {
	msg += `╠➥ @${String(blocked).split('@')[0]}\n`
	
	
}
conn.sendMessage(from,{text: msg, mentions:[blocked]},{quoted:mek})
break	
case "regras_add":
reply(regras_add(prefix, namebot))
break
case "regras_bd":
reply(regras_bonde(prefix, namebot))
break   		   		   
case "depositar":
case "depósitar":
case "deposita":
case "deposito":
case "transferir":
case "transferi":
try{
if (args.length < 2) return reply(`use o exenplo ${prefix}depositar xp-numero `)
userXddp = getLevelingXp(sender)
tira = args[0]
num = args[1].split("@")[1]
num = num + '@s.whatsapp.net'
if (tira >= userXddp ) return reply (5454)
removexp(sender,Number(tira))
addLevelingXp(num, Number(tira))
b = getLevelingXp(num)
hasil = (`Foi Depositado ${tira}XP para @${num.split("@")[0]} pelo @${sender.split("@")[0]}`)

conn.sendMessage(from,{text: hasil, mentions: [num, sender]},  { quoted: mek })
}catch(e){
reply("Dados invalidos")
console.log("ERROR NO COMANDO DEPOSITAR")
console.log(e)
}
		   

case 'rgt':

if (!isUser) return reply(mess.only.daftarB)
if (!isGroupAdmins) return reply(mess.only.admin)
if (Number(args[0]) === 1) {
if (daftor.includes(from)) return reply('Registro já estava bloqueado')
daftor.push(from)
fs.writeFileSync('./database/json/daftar.json', JSON.stringify(daftor))
reply('❬ SUCESSO ❭ O Registro foi Bloqueado neste grupo ')
break
} else if (Number(args[0]) === 0) {
if (!daftor.includes(from)) return reply('o registro continua ativo')
daftor.splice(from, 1)
fs.writeFileSync('./database/json/daftar.json', JSON.stringify(daftor))
reply('❬ SUCESSO ❭Registro desbloqueado ')}
break	
case "x9":		
if (!isGroup) return reply("comando valido, apneas em grupo.")
   if (!isUser) return reply(`Digite ${prefix}daftar nome|idade`)
if (!isGroupAdmins) return reply("Sem autorização")
if (args.length < 1) return reply('digite 1 para ativar')
if (Number(args[0]) === 1) {
	if (x9) return reply('o recurso está ativo')
	x.push(from)
	fs.writeFileSync('./database/json/x9.json', JSON.stringify(x))
	reply('❬ SUCESSO ❭ ativado o recurso de vigilacia neste grupo')
	welkom.splice(from, 1)
	fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
} else if (Number(args[0]) === 0) {
     if (!x9.includes(from)) return reply ('Já estava desativado')
	x.splice(from, 1)
	fs.writeFileSync('./database/json/x9.json', JSON.stringify(x))
	reply('❬ SUCESSO ❭ desativado o recurso de vigilancia neste grupo')
} else {
	reply('digite 1 para ativar, 0 para desativar o recurso')
}
   break
   
case "welcome":		
if (!isGroup) return reply("comando valido, apneas em grupo.")
   if (!isUser) return reply(`Digite ${prefix}daftar nome|idade`)
if (!isGroupAdmins) return reply("Sem autorização")
if (args.length < 1) return reply('digite 1 para ativar')
if (Number(args[0]) === 1) {
	if (isWelkom) return reply('o recurso está ativo')
	welkom.push(from)
	fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
	reply('❬ SUCESSO ❭ ativado o recurso de boas-vindas neste grupo')
	x.splice(from, 1)
	fs.writeFileSync('./database/json/x9.json', JSON.stringify(x))
} else if (Number(args[0]) === 0) {
     if (!welkom.includes(from)) return reply ('Já estava desativado')
	welkom.splice(from, 1)
	fs.writeFileSync('./database/json/welkom.json', JSON.stringify(welkom))
	reply('❬ SUCESSO ❭ desativado o recurso de boas-vindas neste grupo')
} else {
	reply('digite 1 para ativar, 0 para desativar o recurso')
}
   break
   			

case 'meuid':

	         if (!isUser) return reply(`Digite ${prefix}daftar nome|idade`)
	         if (isGroup) return reply("Comando bloqueado em grupo.")
	         let positionP = false
Object.keys(users).forEach((i) => {
if (users[i].numero === sender.split('@')[0]) {
    positionP = i
}
            })
           
            reply(String(positionP))
case 'daftar':
if (isUser) return reply("Você ja esta registardo.") 			
if (args.length < 1) return reply(`Parâmetro incorreto \nCommand : ${prefix}daftar nome|idade\nContoh : ${prefix}daftar Albio|23`)
var reg = body.slice(8)
var nomedu= reg.split("|")[0];

var idadedu = reg.split("|")[1];
isum = Number(idadedu)
if(String(isum) == "NaN"  || idadedu < 10 || idadedu > 100){
return reply("Dados invalido, usuario deletado.")
}
var id = user.length
const ups = {numero: sender.split('@')[0], name:nomedu , idade:idadedu,Nome_do_grupo: groupName ,time1: time,contype: "0",desc: "Não registrado", id: user.length, levelcom: "0" }
users.push(ups)

user.push(sender)
	fs.writeFileSync('./database/json/users.json', JSON.stringify(users))
	fs.writeFileSync('./database/json/user.json', JSON.stringify(user))
reply(`\`\`\`O registro foi bem sucedido com id: ${id}\`\`\`\n\n\`\`\`Data ${date} Hora ${time.split(" ")[1]}\`\`\`\n\`\`\`[Nome]: ${nomedu}\`\`\`\n\`\`\`[Número]: wa.me/${sender.split("@")[0]}\`\`\`\n\`\`\`[Idade]: ${idadedu}\`\`\`\n\`\`\`Para usar o bot\`\`\`\n\`\`\`Por favor\`\`\`\n\`\`\`enviar ${prefix}menu\`\`\`\n\`\`\`\nTotal de usuários ${user.length}\`\`\``)
break
case 'menujogos':
reply("Em desenvolvimendo")
break
case "version":
case "--version":
reply("2.1 beta")
break
case 'nivel':
case 'level':			
if (!isUser) return reply(`Digite ${prefix}daftar nome|idade`)
n = ' '
if (nameuser === "Desconhecido.") {nameuser = sender.split('@')[0]
n = ' @'}
          
if (args.length < 1) {
const userLevel = getLevelingLevel(sender)
const userXp = getLevelingXp(sender)
const mejkll = userXp / 500
mejk = String(mejkll)
if (userLevel === undefined && userXp === undefined) return reply("Voce Não possui xp")
const rnfgh = 5000 * Math.pow(2, userLevel)
var hjlko = (rnfgh - userXp) / 500
var bnn = String(hjlko)
resul = `◪ *LEVEL*\n  ├─ ❏ *Nome* :${n}${nameuser}\n  ├─ ❏ *User XP* : ${userXp}\n  ├─ ❏ *Levelcom* : ${levelcomm}\n  ├─ ❏ *Mensagen* : ${mejk.split('.')[0]}\n  ├─ ❏ *Falta* : ${bnn.split('.')[0]} *Mensagens*\n  └─ ❏ *User Level* : ${userLevel}`
reply(resul)
break
}
if (!isGroupAdmins) return reply("Sem Autorização")
if (Number(args[0]) === 1) {
if (_leveling.includes(from)) return reply('o recurso está ativo')
_leveling.push(from)
fs.writeFileSync('./database/json/leveling.json', JSON.stringify(_leveling))
reply('❬ SUCESSO ❭ ativado ')
break
} else if (Number(args[0]) === 0) {
if (!_leveling) return reply ('Já estava desativado')
_leveling.splice(from, 1)
fs.writeFileSync('./database/json/leveling.json', JSON.stringify(_leveling))
reply('❬ SUCESSO ❭ desativado ')
break
} else {
	console.log(nameuser)
	

}
var hjk =  body.slice(8)
if (!isGroupAdmins) return reply("Você não e adm, só adm pode execultar este comando.")        
var hjkl= hjk.split("|")[0];
let positionyu = false
sem = hjkl+'@s.whatsapp.net'
Object.keys(users).forEach((i) => {
if (users[i].numero === sem.split('@')[0]) {
positionyu = i
} 

if (positionyu !== false) {
 duf = 'sim'
nameuser = users[positionyu].name
idadeuser = users[positionyu].idade
usernum = users[positionyu].numero
usertime = users[positionyu].time1
userdate = date
userdesc = users[positionyu].desc
usertype = users[positionyu].contype
usergroup= users[positionyu].Nome_do_grupo
levelcomm =users[positionyu].levelcom
}})
const userLevel = getLevelingLevel(sem);
const userXp = getLevelingXp(sem);
if (userLevel === undefined && userXp === undefined) return reply("Ele não possui xp")
const mejkl = userXp / 500
mejklll = String(mejkl)
 const rnfgh = 5000 * Math.pow(2, userLevel)
console.log(rnfgh)
console.log(userXp - rnfgh)
   var hjlko = (rnfgh - userXp) / 500
   console.log(hjlko)
   var bnn = String(hjlko)
 
resul = `◪ *LEVEL*\n  ├─ ❏ *Nome* :${n}${nameuser}\n  ├─ ❏ *User XP* : ${userXp}\n  ├─ ❏ *Levelcom* : ${levelcomm}\n  ├─ ❏ *Mensagen* : ${mejklll.split('.')[0]}\n  ├─ ❏ *Falta* : ${bnn.split('.')[0]} *Mensagens*\n  └─ ❏ *User Level* : ${userLevel}`
              reply(resul)
 break
 case 'tagall':

if (!isGroup) return reply("Só em grupo")
if (!isGroupAdmins) return reply("Só pra adm")
members_id = []
teks = (args.length > 1) ? body.slice(8).trim() : ''
teks += `  Total : ${groupMembers.length}\n`
for (let mem of groupMembers) {
	teks += `╠➥ @${mem.id.split('@')[0]}\n`
	members_id.push(mem.id)
	
}
men(from,'╔══✪〘 Mencionando Todos 〙✪══\n╠➥'+teks+'╚═〘  '+"Albion Desenvolvedor"+' 〙',members_id)
break
case 'adminlist':
case 'listadmin':

if (!isGroup) return reply("Só em grupo")
if (!isGroupAdmins) return reply("Só pra adm")
teks = `Lista admin do grupo *${groupMetadata.subject}*\nTotal : ${groupAdmins.length}\n\n`
no = 0
for (let admon of groupAdmins) {
	no += 1
	teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
}
men(from,teks,groupAdmins)
break
case "groupbreak":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`) 			

if (!isGroup) return reply("este comando só pode ser usado em grupo.")
if (!isGroupAdmins) return reply("Sem Autorização")
const b = await conn.groupRevokeInvite(from)
reply(`Novo link: https://chat.whatsapp.com/${b}`)
break
case "setban":
//comando para banir ou desbanir usuario se vc for adm
 if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`) 			

if (!isGroup) return reply("este comando só pode ser usado em grupo.")
if (!isGroupAdmins) return reply("Sem Autorização")
if (args.length < 1) return reply(`use o exenplo ${prefix}setban @user|1 [Desbanir] ou 2 [Banir] {Você pode ser banido se usar errado}`)
u= body.slice(7)
user_ = u.split("|")[0] 
a = u.split("|")[1]
user = user_.split("@")[1] + "@s.whatsapp.net"

if (a === "1"){
if (!userban.includes(user)) return reply ('Esse usuraio já estava desbloqueado')
userban.splice(user,1)
fs.writeFileSync('./database/json/userban.json', JSON.stringify(userban))
}
else if (a === "2"){
if (userban.includes(user)) return reply ('Esse Usuario já esta bloqueado')
userban.push(user)
fs.writeFileSync('./database/json/userban.json', JSON.stringify(userban))
}
else {
if (isOwner) return reply("Tenha mais cuidado, meu dono")
reply("Voçê foi bloqueado por mal uso")
userban.push(sender)
fs.writeFileSync('./database/json/userban.json', JSON.stringify(userban))
}

break	
case "setgroupfoto":
    if (!isGroup) return reply(mess.only.group)
    if (!isGroupAdmins) return reply(mess.only.admin)
   // if (!isBotGroupAdmins) return reply(mess.only.Badmin)
    const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
    media = await conn.downloadMediaMessage(encmedia)
    await albion.updateProfilePicture (from, media)
    reply('Alterou com sucesso o ícone do Grupo')
    break
break	
case "del":
case "delete":
if (!isGroup)return reply(mess.only.group)
   if (!isUser) return reply(mess.only.daftarB)
if (!isGroupAdmins)return reply(mess.only.admin)
await conn.sendMessage(from, { delete: { id: mek.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: from, fromMe: true } })
break
	case 'contar':
if (args.length == 0) return reply( '0 caracteres, pois obviamente não há texto😀')
const count = body.slice(8).length
if (count === 1) {
reply(`O texto possui ${count} caractere.`)
} else if (count > 1) {
reply(`O texto possui ${count} caracteres.`)
}
break
case "dog":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`) 			

reply("Dog morreu")
break	

case "perfil":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`) 			

reply(perfil(nameuser,usernum, usertime, userdesc, usertype, prefix, sender,getLevelingLevel(sender),usergroup, groupName, user, apoia1, blocked, date, time,getLevelingXp(sender),idadeuser))
break
case "promote":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (!groupAdmins) return reply(`Este comando é apenas pra ADM`)
const promo = await conn.groupParticipantsUpdate(from,[`${body.split("@")[1]}@s.whatsapp.net`],"promote")
break
case "demote":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (!groupAdmins) return reply(`Este comando é apenas pra ADM`)
const despromo = await conn.groupParticipantsUpdate(from,[`${body.split("@")[1]}@s.whatsapp.net`],"demote")
break
case "setgroupname":
if (args.length < 1 || args.length > 25) return reply("Nome ivalido, use um nome com menos de 25 carcters e mais que 1 caracters.")
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (!groupAdmins) return reply(`Este comando é apenas pra ADM`)

nome = body.slice(13)
await conn.groupUpdateSubject(from, nome)
break
case "setgroupdesc":
if (args.length < 1 || args.length > 25) return reply("Nome ivalido, use um nome com menos de 25 carcters e mais que 1 caracters.")
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (!groupAdmins) return reply(`Este comando é apenas pra ADM`)

nome = body.slice(12)
await conn.groupUpdateDescription(from, nome)
break
case "closegp":
await conn.groupSettingUpdate(from, 'announcement')
break
case "opengp":
await conn.groupSettingUpdate(from, 'not_announcement')
break
case "configgpuser":
await conn.groupSettingUpdate(from, 'unlocked')
break
case "configgpadmin":
await conn.groupSettingUpdate(from, 'locked')
break
case "linkgp":
let link = await conn.groupInviteCode(from)
reply(`Olá ${nameuser}, aqui está o link deste grupo \n*${groupName}*\n\nhttps://chat.whatsapp.com/${link}`)
break
case "albionban":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (!groupAdmins) return reply(`Este comando é apenas pra ADM`)
const ban = await conn.groupParticipantsUpdate(from,[`${body.split("@")[1]}@s.whatsapp.net`],"remove")
break
case "infogroup":
const dados = await conn.groupMetadata(from) 
reply(`Ola ${nameuser}\n\nInformações do grupo\n\nNome: ${dados.subject}\n\nDescrição: ${dados.desc}\n\nid: ${dados.id}\n\n`)
break
case 'setlevelcom':
if(!isOwner)  return reply("Você não tem autoridade para isso.")
if (args.length < 1) return reply(`use o exenplo ${prefix}settype @user/type `)
let s48f = body.slice(12)
var slrfytf= s48f.split("/")[0];
var slrytf = s48f.split("/")[1];
var uio= slrfytf.split("@")[1];
let position454 = false
Object.keys(users).forEach((i) => {
if (users[i].numero === uio.split('@')[0]) {
    position454 = i
}
            })
            if (position454 !== false) {
nnnn =users[position454].levelcom
              console.log(nnnn)
users[position454].levelcom =''
users[position454].levelcom = slrytf

fs.writeFileSync('./database/json/users.json', JSON.stringify(users))
            }
break
case "join":

if (Number(levelcomm) < 45 ) return reply("Você dentre todos não pode usar este comando.")
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (args.length < 1 ) return reply("Url invalida")
let grupo = body.slice(32)
console.log(grupo)
try{
let join = await conn.groupAcceptInvite(grupo)
reply("Entrei")}catch (e){reply("INCAPAZ")}
break
case "exit":
process.exit(0)
break
case 'levelcom':
reply(levelcom(prefix,nameuser))
               break
               
case "albionadd":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`)
if (!groupAdmins) return reply(`Este comando é apenas pra ADM`)
const addu = await conn.groupParticipantsUpdate(from,[`${body.split("@")[1]}@s.whatsapp.net`],"add")
break
case "blocker":
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`) 
console.log(body.split("@")[1])
await conn.updateBlockStatus(`${body.split("@")[1]}@s.whatsapp.net`, "block")
reply(`Usuario  bloqueado.`)
break

case "desbloquear": // Block user
if (!isUser) return reply(`Você não esta registrado ${prefix}daftar nome|idade`) 
await conn.updateBlockStatus(`${body.split("@")[1]}@s.whatsapp.net`, "unblock") // Unblock user
reply("Usuario desbloqueado")
break

default:
await conn.presenceSubscribe(from) 
if (isCmd && body != undefined) {
	console.log(body)
	reply(`Olá ${nameuser} o comando *${command}* não é reconhecido.`)
} else {
	console.log(color('[WARN]','red'), 'Comando Não Registrado', color(sender.split('@')[0]))
	
	console.log(`\n\n`)
}
}
	


///fggfgfg


})


            
	
  

}catch (e){console.log(String(e))}
}
Albion().catch(e => {
console.log(`${e}`)
})

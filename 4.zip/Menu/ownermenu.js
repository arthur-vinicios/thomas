const ownermenu = (prefix) => {
    return `◪ *Comandos do Owner*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}clearall
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}setban (ADM dos grupos podem desbloquear ou se auto bloquear)`

}

exports.ownermenu = ownermenu
